/**
 * Crawler Service for Bug Bounty Hunter
 * 
 * This service provides advanced crawling capabilities to map web and API endpoints.
 */

class CrawlerService {
  constructor() {
    this.discoveredUrls = new Set();
    this.visitedUrls = new Set();
    this.endpoints = [];
    this.isRunning = false;
    this.config = {
      maxDepth: 3,
      maxUrls: 100,
      respectRobotsTxt: true,
      followRedirects: true,
      includeAssets: false,
      delay: 500
    };
  }

  /**
   * Start crawling from a base URL
   * @param {string} baseUrl - Starting URL for crawling
   * @param {Object} options - Crawling options
   * @returns {Promise<Array>} - Discovered endpoints
   */
  async crawl(baseUrl, options = {}) {
    if (this.isRunning) {
      throw new Error('Crawler is already running');
    }

    try {
      // Merge provided options with defaults
      Object.assign(this.config, options);
      
      // Reset state
      this.discoveredUrls = new Set([baseUrl]);
      this.visitedUrls = new Set();
      this.endpoints = [];
      this.isRunning = true;
      
      console.log(`Starting crawler from ${baseUrl}`);
      
      // In a real implementation, this would perform actual crawling
      // For this demo, we're simulating the crawling process
      await this._simulateCrawling(baseUrl);
      
      this.isRunning = false;
      return this.endpoints;
    } catch (error) {
      console.error('Crawling failed:', error);
      this.isRunning = false;
      return [];
    }
  }

  /**
   * Stop an ongoing crawling process
   */
  stop() {
    if (this.isRunning) {
      this.isRunning = false;
      console.log('Crawler stopped');
    }
  }

  /**
   * Get discovered endpoints
   * @returns {Array} - List of discovered endpoints
   */
  getEndpoints() {
    return this.endpoints;
  }

  /**
   * Export discovered endpoints to JSON format
   * @returns {string} - JSON string of endpoints
   */
  exportToJson() {
    return JSON.stringify(this.endpoints, null, 2);
  }

  /**
   * Simulate the crawling process (for demo purposes)
   * @param {string} baseUrl - Starting URL
   * @private
   */
  async _simulateCrawling(baseUrl) {
    const urlObj = new URL(baseUrl);
    const domain = urlObj.hostname;
    
    // Generate some simulated endpoints based on the base URL
    const paths = [
      '/',
      '/api',
      '/api/users',
      '/api/products',
      '/api/auth/login',
      '/api/auth/register',
      '/about',
      '/contact',
      '/admin',
      '/dashboard'
    ];
    
    // Add some query parameters for API endpoints
    const apiParams = [
      { path: '/api/users', params: { page: '1', limit: '10' } },
      { path: '/api/products', params: { category: 'electronics', sort: 'price' } },
      { path: '/api/search', params: { q: 'test', filter: 'active' } }
    ];
    
    // Add common HTTP methods for API endpoints
    const apiMethods = ['GET', 'POST', 'PUT', 'DELETE'];
    
    // Simulate discovering paths
    for (const path of paths) {
      const url = new URL(path, baseUrl).toString();
      this.discoveredUrls.add(url);
      
      // Simulate visiting the URL
      await this._simulateVisit(url, domain, path);
      
      // Don't continue if crawler was stopped
      if (!this.isRunning) {
        break;
      }
    }
    
    // Simulate discovering API endpoints with parameters
    for (const item of apiParams) {
      const url = new URL(item.path, baseUrl);
      for (const [key, value] of Object.entries(item.params)) {
        url.searchParams.append(key, value);
      }
      
      const urlString = url.toString();
      this.discoveredUrls.add(urlString);
      
      // Simulate visiting the URL
      await this._simulateVisit(urlString, domain, item.path, item.params);
      
      // Don't continue if crawler was stopped
      if (!this.isRunning) {
        break;
      }
    }
    
    // Simulate discovering API methods
    for (const path of paths.filter(p => p.startsWith('/api'))) {
      for (const method of apiMethods) {
        // Skip GET as it's already covered
        if (method === 'GET') continue;
        
        const url = new URL(path, baseUrl).toString();
        
        // Add as an endpoint with the specific method
        this.endpoints.push({
          url,
          method,
          path,
          domain,
          discovered: new Date().toISOString(),
          contentType: 'application/json',
          parameters: [],
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${token}'
          }
        });
      }
    }
  }

  /**
   * Simulate visiting a URL (for demo purposes)
   * @param {string} url - URL to visit
   * @param {string} domain - Domain of the URL
   * @param {string} path - Path of the URL
   * @param {Object} params - URL parameters
   * @private
   */
  async _simulateVisit(url, domain, path, params = {}) {
    // Mark as visited
    this.visitedUrls.add(url);
    
    // Add to endpoints
    const endpoint = {
      url,
      method: 'GET',
      path,
      domain,
      discovered: new Date().toISOString(),
      contentType: path.startsWith('/api') ? 'application/json' : 'text/html',
      parameters: Object.entries(params).map(([name, value]) => ({ name, value })),
      headers: {}
    };
    
    // Add some typical headers based on endpoint type
    if (path.startsWith('/api')) {
      endpoint.headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      };
      
      // Add authorization header for protected endpoints
      if (path.includes('/auth') || path.includes('/admin')) {
        endpoint.headers['Authorization'] = 'Bearer ${token}';
      }
    } else {
      endpoint.headers = {
        'Accept': 'text/html',
        'Content-Type': 'text/html'
      };
    }
    
    this.endpoints.push(endpoint);
    
    // Simulate delay between requests
    await new Promise(resolve => setTimeout(resolve, this.config.delay));
  }
}

module.exports = CrawlerService;

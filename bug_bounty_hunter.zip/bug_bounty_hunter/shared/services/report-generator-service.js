/**
 * Report Generator Service for Bug Bounty Hunter
 * 
 * This service generates detailed vulnerability reports based on findings.
 */

class ReportGeneratorService {
  constructor() {
    this.templates = {
      pdf: 'pdf-template.tex',
      html: 'html-template.html',
      markdown: 'markdown-template.md'
    };
    this.config = {
      defaultFormat: 'pdf',
      includeExecutiveSummary: true,
      includeRemediation: true,
      includeSeverityRatings: true,
      includeScreenshots: true,
      companyLogo: null,
      companyName: 'Bug Bounty Hunter'
    };
  }

  /**
   * Generate a report from vulnerabilities
   * @param {Array} vulnerabilities - List of vulnerabilities
   * @param {Object} options - Report options
   * @returns {Promise<Object>} - Generated report
   */
  async generateReport(vulnerabilities, options = {}) {
    try {
      // Merge provided options with defaults
      const reportConfig = { ...this.config, ...options };
      const format = reportConfig.format || reportConfig.defaultFormat;
      
      // Validate format
      if (!Object.keys(this.templates).includes(format)) {
        throw new Error(`Unsupported report format: ${format}`);
      }
      
      // Generate report content
      const reportContent = this._generateReportContent(vulnerabilities, reportConfig);
      
      // Generate report in requested format
      let report;
      switch (format) {
        case 'pdf':
          report = await this._generatePdfReport(reportContent, reportConfig);
          break;
        case 'html':
          report = await this._generateHtmlReport(reportContent, reportConfig);
          break;
        case 'markdown':
          report = await this._generateMarkdownReport(reportContent, reportConfig);
          break;
      }
      
      return report;
    } catch (error) {
      console.error('Failed to generate report:', error);
      throw error;
    }
  }

  /**
   * Set report template
   * @param {string} format - Report format
   * @param {string} template - Template content or path
   */
  setTemplate(format, template) {
    if (!Object.keys(this.templates).includes(format)) {
      throw new Error(`Unsupported report format: ${format}`);
    }
    this.templates[format] = template;
  }

  /**
   * Set report configuration
   * @param {Object} config - Report configuration
   */
  setConfig(config) {
    Object.assign(this.config, config);
  }

  /**
   * Generate report content structure
   * @param {Array} vulnerabilities - List of vulnerabilities
   * @param {Object} config - Report configuration
   * @returns {Object} - Report content structure
   * @private
   */
  _generateReportContent(vulnerabilities, config) {
    // Calculate statistics
    const stats = this._calculateStatistics(vulnerabilities);
    
    // Generate executive summary
    const executiveSummary = this._generateExecutiveSummary(vulnerabilities, stats, config);
    
    // Generate detailed findings
    const findings = vulnerabilities.map(vuln => this._formatVulnerability(vuln, config));
    
    // Generate recommendations
    const recommendations = this._generateRecommendations(vulnerabilities, config);
    
    return {
      title: 'Vulnerability Assessment Report',
      date: new Date().toISOString(),
      stats,
      executiveSummary,
      findings,
      recommendations,
      metadata: {
        generatedBy: 'Bug Bounty Hunter',
        version: '1.0.0',
        companyName: config.companyName,
        companyLogo: config.companyLogo
      }
    };
  }

  /**
   * Calculate statistics from vulnerabilities
   * @param {Array} vulnerabilities - List of vulnerabilities
   * @returns {Object} - Statistics
   * @private
   */
  _calculateStatistics(vulnerabilities) {
    const stats = {
      total: vulnerabilities.length,
      bySeverity: {
        high: 0,
        medium: 0,
        low: 0,
        info: 0
      },
      byType: {}
    };
    
    // Count by severity
    vulnerabilities.forEach(vuln => {
      const severity = vuln.severity.toLowerCase();
      if (stats.bySeverity[severity] !== undefined) {
        stats.bySeverity[severity]++;
      }
      
      // Count by type
      const type = vuln.type;
      if (!stats.byType[type]) {
        stats.byType[type] = 0;
      }
      stats.byType[type]++;
    });
    
    return stats;
  }

  /**
   * Generate executive summary
   * @param {Array} vulnerabilities - List of vulnerabilities
   * @param {Object} stats - Vulnerability statistics
   * @param {Object} config - Report configuration
   * @returns {string} - Executive summary
   * @private
   */
  _generateExecutiveSummary(vulnerabilities, stats, config) {
    let summary = `This report presents the findings from a security assessment conducted on ${new Date().toLocaleDateString()}. `;
    
    summary += `A total of ${stats.total} vulnerabilities were identified: `;
    summary += `${stats.bySeverity.high} high severity, `;
    summary += `${stats.bySeverity.medium} medium severity, `;
    summary += `${stats.bySeverity.low} low severity, and `;
    summary += `${stats.bySeverity.info} informational findings. `;
    
    // Add risk assessment
    if (stats.bySeverity.high > 0) {
      summary += 'The overall risk is assessed as HIGH. Immediate remediation is recommended for the high severity vulnerabilities.';
    } else if (stats.bySeverity.medium > 0) {
      summary += 'The overall risk is assessed as MEDIUM. Remediation is recommended for the medium severity vulnerabilities.';
    } else {
      summary += 'The overall risk is assessed as LOW. The identified vulnerabilities pose minimal risk but should be addressed as part of regular maintenance.';
    }
    
    return summary;
  }

  /**
   * Format a vulnerability for the report
   * @param {Object} vulnerability - Vulnerability object
   * @param {Object} config - Report configuration
   * @returns {Object} - Formatted vulnerability
   * @private
   */
  _formatVulnerability(vulnerability, config) {
    const formatted = {
      id: vulnerability.id || `VULN-${Date.now().toString(36)}`,
      title: vulnerability.type,
      description: vulnerability.description,
      severity: vulnerability.severity,
      location: vulnerability.location || 'Unknown',
      evidence: vulnerability.evidence || 'No evidence provided',
      impact: vulnerability.impact || this._generateImpact(vulnerability),
      remediation: vulnerability.remediation || 'No remediation steps provided',
      references: vulnerability.references || this._generateReferences(vulnerability)
    };
    
    // Add screenshots if available and enabled
    if (config.includeScreenshots && vulnerability.screenshots) {
      formatted.screenshots = vulnerability.screenshots;
    }
    
    return formatted;
  }

  /**
   * Generate impact description based on vulnerability type
   * @param {Object} vulnerability - Vulnerability object
   * @returns {string} - Impact description
   * @private
   */
  _generateImpact(vulnerability) {
    const type = vulnerability.type.toLowerCase();
    
    if (type.includes('xss')) {
      return 'Cross-Site Scripting vulnerabilities allow attackers to execute malicious scripts in the context of the victim\'s browser, potentially leading to session hijacking, credential theft, or defacement.';
    } else if (type.includes('sql') && type.includes('injection')) {
      return 'SQL Injection vulnerabilities allow attackers to manipulate database queries, potentially leading to unauthorized data access, data modification, or complete database compromise.';
    } else if (type.includes('csrf')) {
      return 'Cross-Site Request Forgery vulnerabilities allow attackers to trick users into performing unintended actions, potentially leading to account compromise or unauthorized data modification.';
    } else if (type.includes('header') || type.includes('security header')) {
      return 'Missing security headers may expose the application to various attacks such as clickjacking, content sniffing, or cross-site scripting.';
    } else {
      return 'This vulnerability may impact the confidentiality, integrity, or availability of the application or its data.';
    }
  }

  /**
   * Generate references based on vulnerability type
   * @param {Object} vulnerability - Vulnerability object
   * @returns {Array} - References
   * @private
   */
  _generateReferences(vulnerability) {
    const type = vulnerability.type.toLowerCase();
    const references = [];
    
    if (type.includes('xss')) {
      references.push({
        title: 'OWASP Cross-Site Scripting',
        url: 'https://owasp.org/www-community/attacks/xss/'
      });
    } else if (type.includes('sql') && type.includes('injection')) {
      references.push({
        title: 'OWASP SQL Injection',
        url: 'https://owasp.org/www-community/attacks/SQL_Injection'
      });
    } else if (type.includes('csrf')) {
      references.push({
        title: 'OWASP Cross-Site Request Forgery',
        url: 'https://owasp.org/www-community/attacks/csrf'
      });
    } else if (type.includes('header') || type.includes('security header')) {
      references.push({
        title: 'OWASP Secure Headers Project',
        url: 'https://owasp.org/www-project-secure-headers/'
      });
    }
    
    // Add general reference
    references.push({
      title: 'OWASP Top Ten',
      url: 'https://owasp.org/www-project-top-ten/'
    });
    
    return references;
  }

  /**
   * Generate recommendations based on vulnerabilities
   * @param {Array} vulnerabilities - List of vulnerabilities
   * @param {Object} config - Report configuration
   * @returns {Array} - Recommendations
   * @private
   */
  _generateRecommendations(vulnerabilities, config) {
    const recommendations = [];
    const recommendationMap = {};
    
    // Generate specific recommendations based on vulnerability types
    vulnerabilities.forEach(vuln => {
      const type = vuln.type.toLowerCase();
      
      if (type.includes('xss') && !recommendationMap['xss']) {
        recommendationMap['xss'] = true;
        recommendations.push({
          title: 'Implement XSS Protection',
          description: 'Implement proper input validation, output encoding, and Content-Security-Policy headers to prevent Cross-Site Scripting attacks.',
          priority: 'High'
        });
      } else if (type.includes('sql') && type.includes('injection') && !recommendationMap['sqli']) {
        recommendationMap['sqli'] = true;
        recommendations.push({
          title: 'Prevent SQL Injection',
          description: 'Use parameterized queries or prepared statements for all database operations. Avoid dynamic SQL construction.',
          priority: 'High'
        });
      } else if (type.includes('csrf') && !recommendationMap['csrf']) {
        recommendationMap['csrf'] = true;
        recommendations.push({
          title: 'Implement CSRF Protection',
          description: 'Implement anti-CSRF tokens for all state-changing operations and validate the token on the server side.',
          priority: 'Medium'
        });
      } else if ((type.includes('header') || type.includes('security header')) && !recommendationMap['headers']) {
        recommendationMap['headers'] = true;
        recommendations.push({
          title: 'Implement Security Headers',
          description: 'Add recommended security headers including Content-Security-Policy, X-Content-Type-Options, X-Frame-Options, and Strict-Transport-Security.',
          priority: 'Medium'
        });
      }
    });
    
    // Add general recommendations
    if (!recommendationMap['general']) {
      recommendations.push({
        title: 'Regular Security Testing',
        description: 'Conduct regular security assessments and penetration testing to identify and address vulnerabilities.',
        priority: 'Medium'
      });
    }
    
    if (!recommendationMap['training']) {
      recommendations.push({
        title: 'Security Training',
        description: 'Provide security awareness training for developers to prevent common security vulnerabilities.',
        priority: 'Medium'
      });
    }
    
    return recommendations;
  }

  /**
   * Generate PDF report
   * @param {Object} content - Report content
   * @param {Object} config - Report configuration
   * @returns {Promise<Object>} - Generated report
   * @private
   */
  async _generatePdfReport(content, config) {
    // In a real implementation, this would generate a PDF using LaTeX
    // For this demo, we're simulating the PDF generation
    
    // Generate LaTeX content
    const latexContent = this._generateLatexContent(content, config);
    
    return {
      format: 'pdf',
      content: latexContent,
      filename: `vulnerability_report_${new Date().toISOString().split('T')[0]}.pdf`,
      mimeType: 'application/pdf'
    };
  }

  /**
   * Generate HTML report
   * @param {Object} content - Report content
   * @param {Object} config - Report configuration
   * @returns {Promise<Object>} - Generated report
   * @private
   */
  async _generateHtmlReport(content, config) {
    // In a real implementation, this would generate HTML
    // For this demo, we're simulating the HTML generation
    
    // Generate HTML content
    const htmlContent = this._generateHtmlContent(content, config);
    
    return {
      format: 'html',
      content: htmlContent,
      filename: `vulnerability_report_${new Date().toISOString().split('T')[0]}.html`,
      mimeType: 'text/html'
    };
  }

  /**
   * Generate Markdown report
   * @param {Object} content - Report content
   * @param {Object} config - Report configuration
   * @returns {Promise<Object>} - Generated report
   * @private
   */
  async _generateMarkdownReport(content, config) {
    // In a real implementation, this would generate Markdown
    // For this demo, we're simulating the Markdown generation
    
    // Generate Markdown content
    const markdownContent = this._generateMarkdownContent(content, config);
    
    return {
      format: 'markdown',
      content: markdownContent,
      filename: `vulnerability_report_${new Date().toISOString().split('T')[0]}.md`,
      mimeType: 'text/markdown'
    };
  }

  /**
   * Generate LaTeX content for PDF report
   * @param {Object} content - Report content
   * @param {Object} config - Report configuration
   * @returns {string} - LaTeX content
   * @private
   */
  _generateLatexContent(content, config) {
    let latex = `
\\documentclass{article}
\\usepackage{geometry}
\\geometry{a4paper, margin=1in}
\\usepackage{graphicx}
\\usepackage{xcolor}
\\usepackage{hyperref}
\\usepackage{enumitem}
\\usepackage{booktabs}
\\usepackage{longtable}
\\usepackage{fancyhdr}
\\pagestyle{fancy}

\\definecolor{high}{RGB}{255,0,0}
\\definecolor{medium}{RGB}{255,165,0}
\\definecolor{low}{RGB}{255,255,0}
\\definecolor{info}{RGB}{0,0,255}

\\title{${content.title}}
\\author{${config.companyName}}
\\date{${new Date().toLocaleDateString()}}

\\begin{document}

\\maketitle
\\tableofcontents
\\newpage

\\section{Executive Summary}
${content.executiveSummary}

\\section{Findings Summary}
\\begin{center}
\\begin{tabular}{lr}
\\toprule
\\textbf{Severity} & \\textbf{Count} \\\\
\\midrule
\\textcolor{high}{High} & ${content.stats.bySeverity.high} \\\\
\\textcolor{medium}{Medium} & ${content.stats.bySeverity.medium} \\\\
\\textcolor{low}{Low} & ${content.stats.bySeverity.low} \\\\
\\textcolor{info}{Informational} & ${content.stats.bySeverity.info} \\\\
\\midrule
\\textbf{Total} & ${content.stats.total} \\\\
\\bottomrule
\\end{tabular}
\\end{center}

\\section{Detailed Findings}
`;

    // Add each vulnerability
    content.findings.forEach((finding, index) => {
      const severityColor = finding.severity.toLowerCase();
      
      latex += `
\\subsection{${index + 1}. ${finding.title}}
\\begin{itemize}
\\item \\textbf{Severity:} \\textcolor{${severityColor}}{${finding.severity}}
\\item \\textbf{Location:} ${finding.location}
\\item \\textbf{Description:} ${finding.description}
\\item \\textbf{Impact:} ${finding.impact}
\\item \\textbf{Remediation:} ${finding.remediation}
\\end{itemize}
`;

      // Add evidence if available
      if (finding.evidence && finding.evidence !== 'No evidence provided') {
        latex += `
\\subsubsection*{Evidence}
\\begin{verbatim}
${finding.evidence}
\\end{verbatim}
`;
      }
      
      // Add screenshots if available
      if (finding.screenshots && finding.screenshots.length > 0) {
        latex += `
\\subsubsection*{Screenshots}
`;
        finding.screenshots.forEach(screenshot => {
          latex += `
\\begin{figure}[h]
\\centering
\\includegraphics[width=0.8\\textwidth]{${screenshot}}
\\caption{Screenshot of ${finding.title}}
\\end{figure}
`;
        });
      }
    });

    // Add recommendations
    latex += `
\\section{Recommendations}
\\begin{enumerate}
`;
    content.recommendations.forEach(rec => {
      latex += `\\item \\textbf{${rec.title}} (${rec.priority}): ${rec.description}\n`;
    });
    latex += `\\end{enumerate}

\\section{Conclusion}
Addressing the identified vulnerabilities is essential to improve the security posture of the application. 
Regular security assessments should be conducted to identify and mitigate potential security risks.

\\end{document}
`;

    return latex;
  }

  /**
   * Generate HTML content for HTML report
   * @param {Object} content - Report content
   * @param {Object} config - Report configuration
   * @returns {string} - HTML content
   * @private
   */
  _generateHtmlContent(content, config) {
    let html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${content.title}</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      margin: 0;
      padding: 20px;
      color: #333;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
    }
    h1, h2, h3 {
      color: #2c3e50;
    }
    .severity {
      display: inline-block;
      padding: 3px 8px;
      border-radius: 3px;
      color: white;
      font-weight: bold;
    }
    .high {
      background-color: #e74c3c;
    }
    .medium {
      background-color: #f39c12;
    }
    .low {
      background-color: #f1c40f;
      color: #333;
    }
    .info {
      background-color: #3498db;
    }
    .finding {
      margin-bottom: 30px;
      border: 1px solid #ddd;
      padding: 15px;
      border-radius: 5px;
    }
    .summary-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    .summary-table th, .summary-table td {
      border: 1px solid #ddd;
      padding: 8px;
      text-align: left;
    }
    .summary-table th {
      background-color: #f2f2f2;
    }
    .evidence {
      background-color: #f9f9f9;
      padding: 10px;
      border-radius: 5px;
      font-family: monospace;
      white-space: pre-wrap;
    }
    .screenshot {
      max-width: 100%;
      margin: 10px 0;
      border: 1px solid #ddd;
    }
    .recommendation {
      margin-bottom: 15px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>${content.title}</h1>
    <p><strong>Date:</strong> ${new Date(content.date).toLocaleDateString()}</p>
    <p><strong>Generated by:</strong> ${content.metadata.generatedBy} v${content.metadata.version}</p>
    
    <h2>Executive Summary</h2>
    <p>${content.executiveSummary}</p>
    
    <h2>Findings Summary</h2>
    <table class="summary-table">
      <tr>
        <th>Severity</th>
        <th>Count</th>
      </tr>
      <tr>
        <td><span class="severity high">High</span></td>
        <td>${content.stats.bySeverity.high}</td>
      </tr>
      <tr>
        <td><span class="severity medium">Medium</span></td>
        <td>${content.stats.bySeverity.medium}</td>
      </tr>
      <tr>
        <td><span class="severity low">Low</span></td>
        <td>${content.stats.bySeverity.low}</td>
      </tr>
      <tr>
        <td><span class="severity info">Informational</span></td>
        <td>${content.stats.bySeverity.info}</td>
      </tr>
      <tr>
        <th>Total</th>
        <td>${content.stats.total}</td>
      </tr>
    </table>
    
    <h2>Detailed Findings</h2>`;

    // Add each vulnerability
    content.findings.forEach((finding, index) => {
      const severityClass = finding.severity.toLowerCase();
      
      html += `
    <div class="finding">
      <h3>${index + 1}. ${finding.title}</h3>
      <p><strong>Severity:</strong> <span class="severity ${severityClass}">${finding.severity}</span></p>
      <p><strong>Location:</strong> ${finding.location}</p>
      <p><strong>Description:</strong> ${finding.description}</p>
      <p><strong>Impact:</strong> ${finding.impact}</p>
      <p><strong>Remediation:</strong> ${finding.remediation}</p>`;

      // Add evidence if available
      if (finding.evidence && finding.evidence !== 'No evidence provided') {
        html += `
      <h4>Evidence</h4>
      <div class="evidence">${finding.evidence}</div>`;
      }
      
      // Add screenshots if available
      if (finding.screenshots && finding.screenshots.length > 0) {
        html += `
      <h4>Screenshots</h4>`;
        finding.screenshots.forEach(screenshot => {
          html += `
      <img src="${screenshot}" alt="Screenshot of ${finding.title}" class="screenshot">`;
        });
      }
      
      html += `
    </div>`;
    });

    // Add recommendations
    html += `
    <h2>Recommendations</h2>
    <ol>`;
    content.recommendations.forEach(rec => {
      html += `
      <li class="recommendation">
        <strong>${rec.title}</strong> (${rec.priority}): ${rec.description}
      </li>`;
    });
    html += `
    </ol>
    
    <h2>Conclusion</h2>
    <p>Addressing the identified vulnerabilities is essential to improve the security posture of the application. 
    Regular security assessments should be conducted to identify and mitigate potential security risks.</p>
  </div>
</body>
</html>`;

    return html;
  }

  /**
   * Generate Markdown content for Markdown report
   * @param {Object} content - Report content
   * @param {Object} config - Report configuration
   * @returns {string} - Markdown content
   * @private
   */
  _generateMarkdownContent(content, config) {
    let markdown = `# ${content.title}

**Date:** ${new Date(content.date).toLocaleDateString()}  
**Generated by:** ${content.metadata.generatedBy} v${content.metadata.version}

## Executive Summary

${content.executiveSummary}

## Findings Summary

| Severity | Count |
|----------|-------|
| High | ${content.stats.bySeverity.high} |
| Medium | ${content.stats.bySeverity.medium} |
| Low | ${content.stats.bySeverity.low} |
| Informational | ${content.stats.bySeverity.info} |
| **Total** | **${content.stats.total}** |

## Detailed Findings

`;

    // Add each vulnerability
    content.findings.forEach((finding, index) => {
      markdown += `### ${index + 1}. ${finding.title}

**Severity:** ${finding.severity}  
**Location:** ${finding.location}  
**Description:** ${finding.description}  
**Impact:** ${finding.impact}  
**Remediation:** ${finding.remediation}  

`;

      // Add evidence if available
      if (finding.evidence && finding.evidence !== 'No evidence provided') {
        markdown += `#### Evidence

\`\`\`
${finding.evidence}
\`\`\`

`;
      }
      
      // Add screenshots if available
      if (finding.screenshots && finding.screenshots.length > 0) {
        markdown += `#### Screenshots

`;
        finding.screenshots.forEach(screenshot => {
          markdown += `![Screenshot of ${finding.title}](${screenshot})

`;
        });
      }
    });

    // Add recommendations
    markdown += `## Recommendations

`;
    content.recommendations.forEach((rec, index) => {
      markdown += `${index + 1}. **${rec.title}** (${rec.priority}): ${rec.description}

`;
    });

    markdown += `## Conclusion

Addressing the identified vulnerabilities is essential to improve the security posture of the application. 
Regular security assessments should be conducted to identify and mitigate potential security risks.
`;

    return markdown;
  }
}

module.exports = ReportGeneratorService;

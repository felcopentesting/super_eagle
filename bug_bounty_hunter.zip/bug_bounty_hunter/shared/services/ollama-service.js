/**
 * Ollama Service for Bug Bounty Hunter
 * 
 * This service integrates with Ollama LLMs for AI-assisted vulnerability testing
 * and report generation.
 */

class OllamaService {
  constructor() {
    this.baseUrl = 'http://localhost:11434';
    this.model = 'llama3.1';
    this.isConnected = false;
    this.history = [];
  }

  /**
   * Initialize connection to Ollama
   * @param {Object} config - Configuration options
   * @returns {Promise<boolean>} - Connection status
   */
  async initialize(config = {}) {
    try {
      this.baseUrl = config.baseUrl || this.baseUrl;
      this.model = config.model || this.model;
      
      // In a real implementation, this would test the connection to Ollama
      // For this demo, we're simulating the connection
      this.isConnected = true;
      
      console.log(`Ollama service initialized with model: ${this.model}`);
      return true;
    } catch (error) {
      console.error('Failed to initialize Ollama service:', error);
      this.isConnected = false;
      return false;
    }
  }

  /**
   * Analyze a request for vulnerabilities
   * @param {Object} request - Request object to analyze
   * @returns {Promise<Array>} - List of detected vulnerabilities
   */
  async analyzeRequest(request) {
    if (!this.isConnected) {
      throw new Error('Ollama service not connected');
    }

    try {
      // In a real implementation, this would call the Ollama API
      // For this demo, we're simulating the analysis
      
      const prompt = `Analyze this HTTP request for vulnerabilities (e.g., XSS, SQLi, CSRF). 
      Provide type, description, and severity (Low/Medium/High): ${JSON.stringify(request)}`;
      
      // Record the interaction in history
      const interaction = {
        timestamp: new Date().toISOString(),
        type: 'request-analysis',
        input: prompt
      };
      
      // Simulate analysis based on request properties
      const vulnerabilities = [];
      
      // Check for potential XSS in query parameters
      if (request.url && request.url.includes('?') && 
          (request.url.includes('script') || request.url.includes('alert'))) {
        vulnerabilities.push({
          type: 'XSS',
          description: 'Potential Cross-Site Scripting vulnerability detected in URL parameters',
          severity: 'High',
          location: 'URL',
          remediation: 'Implement proper input validation and output encoding'
        });
      }
      
      // Check for potential SQL injection
      if ((request.body && (request.body.includes("'") || request.body.includes('"'))) ||
          (request.url && (request.url.includes("'") || request.url.includes('"')))) {
        vulnerabilities.push({
          type: 'SQL Injection',
          description: 'Potential SQL Injection vulnerability detected in request',
          severity: 'High',
          location: request.body ? 'Body' : 'URL',
          remediation: 'Use parameterized queries or prepared statements'
        });
      }
      
      // Check for missing security headers
      if (request.headers && !request.headers['content-security-policy']) {
        vulnerabilities.push({
          type: 'Missing Security Headers',
          description: 'Content-Security-Policy header is missing',
          severity: 'Medium',
          location: 'Headers',
          remediation: 'Implement Content-Security-Policy header'
        });
      }
      
      // Complete the interaction record
      interaction.output = vulnerabilities;
      this.history.push(interaction);
      
      return vulnerabilities;
    } catch (error) {
      console.error('Failed to analyze request:', error);
      return [];
    }
  }

  /**
   * Generate a vulnerability report
   * @param {Array} vulnerabilities - List of vulnerabilities
   * @returns {Promise<Object>} - Generated report
   */
  async generateReport(vulnerabilities) {
    if (!this.isConnected) {
      throw new Error('Ollama service not connected');
    }

    try {
      // In a real implementation, this would call the Ollama API
      // For this demo, we're simulating the report generation
      
      const prompt = `Generate a professional vulnerability report for these findings: ${JSON.stringify(vulnerabilities)}`;
      
      // Record the interaction in history
      const interaction = {
        timestamp: new Date().toISOString(),
        type: 'report-generation',
        input: prompt
      };
      
      // Simulate report generation
      const currentDate = new Date().toLocaleDateString();
      
      const report = {
        title: 'Vulnerability Assessment Report',
        date: currentDate,
        summary: `This report summarizes the findings from a security assessment conducted on ${currentDate}. 
                 A total of ${vulnerabilities.length} vulnerabilities were identified.`,
        findings: vulnerabilities,
        riskRating: this._calculateRiskRating(vulnerabilities),
        recommendations: this._generateRecommendations(vulnerabilities),
        content: this._generateReportContent(vulnerabilities)
      };
      
      // Complete the interaction record
      interaction.output = report;
      this.history.push(interaction);
      
      return report;
    } catch (error) {
      console.error('Failed to generate report:', error);
      return {
        title: 'Error Generating Report',
        date: new Date().toLocaleDateString(),
        summary: 'An error occurred while generating the report.',
        findings: vulnerabilities,
        riskRating: 'Unknown',
        recommendations: [],
        content: 'Report generation failed.'
      };
    }
  }

  /**
   * Get interaction history
   * @returns {Array} - History of interactions
   */
  getHistory() {
    return this.history;
  }

  /**
   * Clear interaction history
   */
  clearHistory() {
    this.history = [];
  }

  /**
   * Calculate overall risk rating based on vulnerabilities
   * @param {Array} vulnerabilities - List of vulnerabilities
   * @returns {string} - Risk rating
   * @private
   */
  _calculateRiskRating(vulnerabilities) {
    if (!vulnerabilities || vulnerabilities.length === 0) {
      return 'Low';
    }
    
    const hasHigh = vulnerabilities.some(v => v.severity === 'High');
    const hasMedium = vulnerabilities.some(v => v.severity === 'Medium');
    
    if (hasHigh) {
      return 'High';
    } else if (hasMedium) {
      return 'Medium';
    } else {
      return 'Low';
    }
  }

  /**
   * Generate recommendations based on vulnerabilities
   * @param {Array} vulnerabilities - List of vulnerabilities
   * @returns {Array} - List of recommendations
   * @private
   */
  _generateRecommendations(vulnerabilities) {
    const recommendations = [];
    
    if (vulnerabilities.some(v => v.type === 'XSS')) {
      recommendations.push({
        title: 'Implement XSS Protection',
        description: 'Implement proper input validation, output encoding, and Content-Security-Policy headers to prevent Cross-Site Scripting attacks.'
      });
    }
    
    if (vulnerabilities.some(v => v.type === 'SQL Injection')) {
      recommendations.push({
        title: 'Prevent SQL Injection',
        description: 'Use parameterized queries or prepared statements for all database operations. Avoid dynamic SQL construction.'
      });
    }
    
    if (vulnerabilities.some(v => v.type === 'Missing Security Headers')) {
      recommendations.push({
        title: 'Implement Security Headers',
        description: 'Add recommended security headers including Content-Security-Policy, X-Content-Type-Options, X-Frame-Options, and Strict-Transport-Security.'
      });
    }
    
    // Add general recommendation
    recommendations.push({
      title: 'Regular Security Testing',
      description: 'Conduct regular security assessments and penetration testing to identify and address vulnerabilities.'
    });
    
    return recommendations;
  }

  /**
   * Generate detailed report content
   * @param {Array} vulnerabilities - List of vulnerabilities
   * @returns {string} - Report content
   * @private
   */
  _generateReportContent(vulnerabilities) {
    let content = '# Vulnerability Assessment Report\n\n';
    
    content += '## Executive Summary\n\n';
    content += `This report presents the findings from a security assessment conducted on ${new Date().toLocaleDateString()}. `;
    content += `A total of ${vulnerabilities.length} vulnerabilities were identified. `;
    
    const riskRating = this._calculateRiskRating(vulnerabilities);
    content += `The overall risk rating is ${riskRating}.\n\n`;
    
    content += '## Findings\n\n';
    
    vulnerabilities.forEach((vuln, index) => {
      content += `### ${index + 1}. ${vuln.type}\n\n`;
      content += `**Severity:** ${vuln.severity}\n\n`;
      content += `**Description:** ${vuln.description}\n\n`;
      content += `**Location:** ${vuln.location}\n\n`;
      content += `**Remediation:** ${vuln.remediation}\n\n`;
    });
    
    content += '## Recommendations\n\n';
    
    const recommendations = this._generateRecommendations(vulnerabilities);
    recommendations.forEach((rec, index) => {
      content += `### ${index + 1}. ${rec.title}\n\n`;
      content += `${rec.description}\n\n`;
    });
    
    content += '## Conclusion\n\n';
    content += 'Addressing the identified vulnerabilities is essential to improve the security posture of the application. ';
    content += 'Regular security assessments should be conducted to identify and mitigate potential security risks.';
    
    return content;
  }
}

module.exports = OllamaService;

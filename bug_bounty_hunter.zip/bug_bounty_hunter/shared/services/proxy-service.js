/**
 * Proxy Service for Bug Bounty Hunter
 * 
 * This service handles HTTP/HTTPS traffic interception using node-mitmproxy.
 * It provides functionality to intercept, analyze, and modify requests and responses.
 */

const EventEmitter = require('events');

class ProxyService extends EventEmitter {
  constructor() {
    super();
    this.interceptedRequests = [];
    this.interceptedResponses = [];
    this.isRunning = false;
    this.port = 8080;
    this.config = {
      enableSSL: true,
      sslCaDir: './ssl',
      enableFilters: true,
      filterRules: []
    };
  }

  /**
   * Start the proxy service
   * @param {Object} options - Configuration options
   * @returns {Promise<boolean>} - Success status
   */
  async start(options = {}) {
    if (this.isRunning) {
      return true;
    }

    try {
      // Merge provided options with defaults
      this.port = options.port || this.port;
      Object.assign(this.config, options);

      // In a real implementation, this would initialize node-mitmproxy
      // For this demo, we're simulating the proxy functionality
      this.isRunning = true;
      
      // Emit started event
      this.emit('started', { port: this.port });
      
      console.log(`Proxy service started on port ${this.port}`);
      return true;
    } catch (error) {
      console.error('Failed to start proxy service:', error);
      return false;
    }
  }

  /**
   * Stop the proxy service
   * @returns {Promise<boolean>} - Success status
   */
  async stop() {
    if (!this.isRunning) {
      return true;
    }

    try {
      // In a real implementation, this would stop node-mitmproxy
      this.isRunning = false;
      
      // Emit stopped event
      this.emit('stopped');
      
      console.log('Proxy service stopped');
      return true;
    } catch (error) {
      console.error('Failed to stop proxy service:', error);
      return false;
    }
  }

  /**
   * Add a request interceptor
   * @param {Function} interceptor - Function to process requests
   */
  addRequestInterceptor(interceptor) {
    this.on('request', interceptor);
  }

  /**
   * Add a response interceptor
   * @param {Function} interceptor - Function to process responses
   */
  addResponseInterceptor(interceptor) {
    this.on('response', interceptor);
  }

  /**
   * Get all intercepted requests
   * @returns {Array} - List of intercepted requests
   */
  getRequests() {
    return this.interceptedRequests;
  }

  /**
   * Get all intercepted responses
   * @returns {Array} - List of intercepted responses
   */
  getResponses() {
    return this.interceptedResponses;
  }

  /**
   * Clear all intercepted requests and responses
   */
  clearHistory() {
    this.interceptedRequests = [];
    this.interceptedResponses = [];
    this.emit('history-cleared');
  }

  /**
   * Add a filter rule
   * @param {Object} rule - Filter rule
   */
  addFilterRule(rule) {
    this.config.filterRules.push(rule);
  }

  /**
   * Remove a filter rule
   * @param {number} index - Index of the rule to remove
   */
  removeFilterRule(index) {
    if (index >= 0 && index < this.config.filterRules.length) {
      this.config.filterRules.splice(index, 1);
    }
  }

  /**
   * Simulate a request interception (for demo purposes)
   * @param {Object} request - Request object
   */
  simulateRequest(request) {
    const interceptedRequest = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      method: request.method,
      url: request.url,
      headers: request.headers,
      body: request.body || '',
      query: request.query || {}
    };
    
    this.interceptedRequests.push(interceptedRequest);
    this.emit('request', interceptedRequest);
    return interceptedRequest;
  }

  /**
   * Simulate a response interception (for demo purposes)
   * @param {Object} response - Response object
   * @param {string} requestId - ID of the corresponding request
   */
  simulateResponse(response, requestId) {
    const interceptedResponse = {
      id: Date.now().toString(),
      requestId,
      timestamp: new Date().toISOString(),
      status: response.status,
      statusText: response.statusText,
      headers: response.headers,
      body: response.body || ''
    };
    
    this.interceptedResponses.push(interceptedResponse);
    this.emit('response', interceptedResponse);
    return interceptedResponse;
  }
}

module.exports = ProxyService;

# Bug Bounty Hunter

A cross-platform bug bounty hunting tool that functions as a proxy interceptor, integrates Ollama LLMs for AI-assisted vulnerability testing, and surpasses Burp Suite and OWASP ZAP in features.

## Overview

Bug Bounty Hunter is a hybrid application designed for security researchers and bug bounty hunters, providing advanced tools for web application security testing across multiple platforms:

- **Web App**: Browser-based interface for accessibility
- **Mobile App**: React Native app for iOS and Android
- **Desktop App**: Electron-based app for Windows, macOS, and Linux

## Key Features

- **Proxy Interceptor**: Intercept and analyze HTTP/HTTPS traffic
- **AI-Assisted Vulnerability Testing**: Ollama LLMs analyze traffic and suggest exploits
- **Advanced Crawler**: Map web and API endpoints
- **Automated Fuzzing**: Test inputs and parameters for vulnerabilities
- **AI Report Generation**: Generate detailed, professional reports with remediation steps
- **Cross-Platform Sync**: Real-time sync of sessions and findings across devices
- **Extensibility**: Plugin system for custom vulnerability checks

## Architecture

- **Frontend**:
  - Web: React with Tailwind CSS
  - Mobile: React Native
  - Desktop: Electron with shared React frontend
- **Backend**:
  - Node.js with Express for API and proxy services
  - SQLite for local storage, MongoDB for cloud sync
- **Proxy**:
  - node-mitmproxy for traffic interception
- **AI**:
  - Ollama LLM for vulnerability detection and report generation

## Getting Started

### Prerequisites

- Node.js 16+
- npm or yarn
- Ollama (for AI features)

### Installation

#### Desktop App

```bash
cd desktop
npm install
npm start
```

#### Web App

```bash
cd web
npm install
npm start
```

#### Mobile App

```bash
cd mobile
npm install
npx react-native run-android # or run-ios
```

## Development

### Project Structure

```
bug_bounty_hunter/
├── web/               # Web application
├── mobile/            # Mobile application
├── desktop/           # Desktop application
├── shared/            # Shared components and services
│   ├── services/      # Core services
│   │   ├── proxy-service.js
│   │   ├── ollama-service.js
│   │   ├── crawler-service.js
│   │   └── report-generator-service.js
│   └── utils/         # Utility functions
└── docs/              # Documentation
```

### Building

#### Desktop App

```bash
cd desktop
npm run build
```

#### Web App

```bash
cd web
npm run build
```

#### Mobile App

```bash
cd mobile
npm run build
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

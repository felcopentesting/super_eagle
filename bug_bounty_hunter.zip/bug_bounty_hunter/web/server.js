const express = require('express');
const ProxyService = require('../../shared/services/proxy-service');
const OllamaService = require('../../shared/services/ollama-service');
const ReportGeneratorService = require('../../shared/services/report-generator-service');

const app = express();
app.use(express.json());
app.use(express.static('public'));

// Initialize services
const proxyService = new ProxyService();
const ollamaService = new OllamaService();
const reportGenerator = new ReportGeneratorService();

// Start proxy service
proxyService.start({ port: 8080 });

// Initialize Ollama service
ollamaService.initialize({ model: 'llama3.1' });

// API endpoints
app.get('/api/proxy/requests', (req, res) => {
  res.json(proxyService.getRequests());
});

app.post('/api/ollama/analyze', async (req, res) => {
  try {
    const { request } = req.body;
    const vulnerabilities = await ollamaService.analyzeRequest(request);
    res.json({ vulnerabilities });
  } catch (error) {
    res.status(500).json({ error: 'Analysis failed' });
  }
});

app.post('/api/ollama/report', async (req, res) => {
  try {
    const { vulnerabilities } = req.body;
    const report = await reportGenerator.generateReport(vulnerabilities, { format: 'markdown' });
    res.json({ report: report.content });
  } catch (error) {
    res.status(500).json({ error: 'Report generation failed' });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

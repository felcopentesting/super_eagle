import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  FlatList,
} from 'react-native';

const App = () => {
  const [requests, setRequests] = useState([]);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [vulnerabilities, setVulnerabilities] = useState([]);
  const [isProxyRunning, setIsProxyRunning] = useState(false);
  const [port, setPort] = useState('8080');

  // Simulate fetching requests
  useEffect(() => {
    if (isProxyRunning) {
      const interval = setInterval(() => {
        // This would be an actual API call in a real implementation
        const mockRequests = [
          {
            id: '1',
            method: 'GET',
            url: 'https://example.com/api/users',
            timestamp: new Date().toISOString(),
          },
          {
            id: '2',
            method: 'POST',
            url: 'https://example.com/api/login',
            timestamp: new Date().toISOString(),
          },
        ];
        setRequests(mockRequests);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isProxyRunning]);

  const toggleProxy = () => {
    setIsProxyRunning(!isProxyRunning);
  };

  const analyzeRequest = (request) => {
    setSelectedRequest(request);
    // This would be an actual API call in a real implementation
    const mockVulnerabilities = [
      {
        type: 'XSS',
        description: 'Potential Cross-Site Scripting vulnerability detected',
        severity: 'High',
      },
    ];
    setVulnerabilities(mockVulnerabilities);
  };

  const renderRequestItem = ({ item }) => (
    <TouchableOpacity
      style={styles.requestItem}
      onPress={() => analyzeRequest(item)}
    >
      <Text style={styles.requestMethod}>{item.method}</Text>
      <Text style={styles.requestUrl}>{item.url}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Bug Bounty Hunter</Text>
      </View>

      <View style={styles.proxyControls}>
        <View style={styles.portContainer}>
          <Text style={styles.label}>Port:</Text>
          <TextInput
            style={styles.portInput}
            value={port}
            onChangeText={setPort}
            keyboardType="numeric"
          />
        </View>
        <TouchableOpacity
          style={[
            styles.proxyButton,
            { backgroundColor: isProxyRunning ? '#e74c3c' : '#2ecc71' },
          ]}
          onPress={toggleProxy}
        >
          <Text style={styles.proxyButtonText}>
            {isProxyRunning ? 'Stop Proxy' : 'Start Proxy'}
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <View style={styles.requestsContainer}>
          <Text style={styles.sectionTitle}>Intercepted Requests</Text>
          {requests.length > 0 ? (
            <FlatList
              data={requests}
              renderItem={renderRequestItem}
              keyExtractor={(item) => item.id}
            />
          ) : (
            <Text style={styles.emptyText}>
              {isProxyRunning
                ? 'Waiting for requests...'
                : 'Start proxy to intercept requests'}
            </Text>
          )}
        </View>

        <View style={styles.detailsContainer}>
          <Text style={styles.sectionTitle}>Request Details</Text>
          {selectedRequest ? (
            <View>
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Method:</Text>
                <Text style={styles.detailValue}>{selectedRequest.method}</Text>
              </View>
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>URL:</Text>
                <Text style={styles.detailValue}>{selectedRequest.url}</Text>
              </View>
              <View style={styles.detailItem}>
                <Text style={styles.detailLabel}>Timestamp:</Text>
                <Text style={styles.detailValue}>
                  {selectedRequest.timestamp}
                </Text>
              </View>

              <Text style={[styles.sectionTitle, { marginTop: 20 }]}>
                Vulnerabilities
              </Text>
              {vulnerabilities.length > 0 ? (
                vulnerabilities.map((vuln, index) => (
                  <View key={index} style={styles.vulnerabilityItem}>
                    <Text style={styles.vulnerabilityType}>{vuln.type}</Text>
                    <Text style={styles.vulnerabilityDescription}>
                      {vuln.description}
                    </Text>
                    <Text
                      style={[
                        styles.vulnerabilitySeverity,
                        {
                          color:
                            vuln.severity === 'High'
                              ? '#e74c3c'
                              : vuln.severity === 'Medium'
                              ? '#f39c12'
                              : '#2ecc71',
                        },
                      ]}
                    >
                      Severity: {vuln.severity}
                    </Text>
                  </View>
                ))
              ) : (
                <Text style={styles.emptyText}>No vulnerabilities found</Text>
              )}
            </View>
          ) : (
            <Text style={styles.emptyText}>Select a request to view details</Text>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#2c3e50',
    padding: 15,
    alignItems: 'center',
  },
  headerTitle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  proxyControls: {
    flexDirection: 'row',
    padding: 15,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  portContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  label: {
    marginRight: 10,
    fontSize: 16,
  },
  portInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: 5,
    width: 80,
    fontSize: 16,
  },
  proxyButton: {
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 5,
  },
  proxyButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    flexDirection: 'row',
  },
  requestsContainer: {
    flex: 1,
    borderRightWidth: 1,
    borderRightColor: '#ddd',
    backgroundColor: 'white',
  },
  detailsContainer: {
    flex: 2,
    backgroundColor: 'white',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  requestItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  requestMethod: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  requestUrl: {
    color: '#3498db',
  },
  emptyText: {
    padding: 15,
    color: '#7f8c8d',
    fontStyle: 'italic',
  },
  detailItem: {
    flexDirection: 'row',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  detailLabel: {
    fontWeight: 'bold',
    width: 100,
  },
  detailValue: {
    flex: 1,
  },
  vulnerabilityItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    backgroundColor: '#fff9f9',
  },
  vulnerabilityType: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 5,
  },
  vulnerabilityDescription: {
    marginBottom: 5,
  },
  vulnerabilitySeverity: {
    fontWeight: 'bold',
  },
});

export default App;
